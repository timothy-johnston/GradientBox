// For color conversions:
// https://github.com/bgrins/TinyColor